import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Hello Dojo!</h1>
      <h3>Things I need to do:</h3>
      <ul>
        <li>Learn React</li>
        <li>Take Dog on Hike</li>
        <li>Cut hair</li>
        <li>Get a real job</li>
        <li>clean act up</li>
        <li>don't be a slob</li>
      </ul>
    </div>
  );
}

export default App;
