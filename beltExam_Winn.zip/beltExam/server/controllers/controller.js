// ! require model
const Store = require('../models/model');


// -------------GET ALL------------
module.exports.getAll = (req, res) => {
    Store.find()
        .then((stores) => {
            res.json({ stores })
        })
        .catch((error) => {
            res.status(400).json({ message: 'It is time to debug', error });
        });
};


// ----------------GET ONE-------------------
module.exports.getOne = (req, res) => {
    Store.findOne({ _id: req.params.id })
        .then((store) => {
            res.json({ store })
        })
        .catch((error) => {
            res.status(400).json({ message: 'It is time to debug', error });
        });
};

// --------------CREATE-----------------------
module.exports.create = (req, res) => {
    Store.create(req.body)
        .then((store) => {
            res.json({ store })
        })
        .catch((error) => {
            res.status(400).json({ message: 'It is time to debug', error });
        });
};


// ------------UPDATE----------------
module.exports.update = (req, res) => {
    Store.findOneAndUpdate({ _id: req.params.id }, req.body, {
        new: true,
        runValidators: true 
    })
        .then((store) => {
            res.json({ store })
        })
        .catch((error) => {
            res.status(400).json({ message: 'It is time to debug', error });
        });
};

// ---------------DELETE-------------------
module.exports.delete = (req, res) => {
    Store.deleteOne({ _id: req.params.id })
        .then((store) => {
            res.json({ store })
        })
        .catch((error) => {
            res.status(400).json({ message: 'It is time to debug', error });
        });
};



