// !UPDATE THIS
const StoreController = require('../controllers/controller');

module.exports = (app) => {
    app.get('/api/stores', StoreController.getAll)
    app.post('/api/stores', StoreController.create)
    app.get('/api/stores/:id', StoreController.getOne)
    app.put('/api/stores/:id', StoreController.update)
    app.delete('/api/stores/:id', StoreController.delete)
};