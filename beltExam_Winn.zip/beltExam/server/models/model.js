const mongoose = require('mongoose');

const StoreSchema = mongoose.Schema(
    {
        storeName: {
            type: String,
            required: [true, 'Name is required'],
            minlength: [3, 'Name much be at least 3 characters']
        },
        storeNumber: {
            type: Number,
            required: [true, 'store number is required'],
            min: [1 , 'store number must be greater than 0']
        },
        storeOpen: {
            type : Boolean, 
            
        }

    },
    { timestamps: true }
)

const Store = mongoose.model('Store' , StoreSchema);

module.exports = Store;