import { Routes, Route, Link } from "react-router-dom";
import React from "react";
import './App.css';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline'
import Main from "./views/Main";
import Add from "./views/Add";
import Update from "./views/Update";
import Detail from "./views/Detail";




function App() {

  const darkTheme = createTheme({
    palette: {
      mode: 'dark',
      primary: {
        main: '#27c9de',
      },
      secondary: {
        main: '#9d81e6',
      },
      error: {
        main: '#d62319',
      },
    },
  })

  return (
    <div className="App">
      <ThemeProvider theme={darkTheme}>
        <CssBaseline />
        <h1>Store Finder</h1>
        <h5>Find Stores in Your Area</h5>
        <Routes>
          <Route element={<Main />} path='/' />
          <Route element={<Detail />} path='/store/:id' />
          <Route element={<Add />} path='/store/add' />
          <Route element={<Update />} path='/store/edit/:id' />
        </Routes>
      </ThemeProvider>

    </div>
  );
}

export default App;
