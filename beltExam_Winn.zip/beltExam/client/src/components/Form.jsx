import React, { useState } from 'react';
import { TextField, Button, Grid, Checkbox } from '@mui/material';

export default (props) => {
  const { submitForm, errors, storeInfo } = props;
  const [storeName, setStoreName] = useState(storeInfo.storeName);
  const [storeNumber, setStoreNumber] = useState(storeInfo.storeNumber);
  const [storeOpen, setStoreOpen] = useState(storeInfo.storeOpen);

  const handleSubmit = (e) => {
    e.preventDefault();

    submitForm({
      storeName,
      storeNumber,
      storeOpen,
    });
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <Grid
          container
          direction='column'
          rowSpacing={2}
          justifyContent='space-around'
        >
          <Grid item>
            <TextField
              className='box'
              id='outlined'
              label='Store Name'
              value={storeName}
              onChange={(e) => setStoreName(e.target.value)}
            />
            {errors.storeName && <p>{errors.storeName.message}</p>}
          </Grid>
          <Grid item>
            <TextField
              className='box'
              id='outlined'
              label='Number'
              value={storeNumber}
              onChange={(e) => setStoreNumber(e.target.value)}
            />
            {errors.storeNumber && <p>{errors.storeNumber.message}</p>}
          </Grid>
          <Grid item>
            <div>
              Open?
              <input
                type='checkbox'
                className='box'
                checked={storeOpen}
                onChange={(e) => setStoreOpen(e.target.checked)}
              />
            </div>
          </Grid>
          <Grid item>
            <Button type='submit' variant='outlined'>
              Submit
            </Button>
          </Grid>
        </Grid>
      </form>
    </div>
  );
};
