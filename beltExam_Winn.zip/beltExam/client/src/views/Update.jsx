import React, { useState, useEffect } from 'react';
import Form from '../components/Form';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const Update = () => {
    // ! CHANGE STATE NAMES TO MATCH DB
  const [store, setStore] = useState('');
  const [formErrors, setFormErrors] = useState({});
  const { id } = useParams();
  const nav = useNavigate();

  useEffect(() => {
    axios.get(`http://localhost:8080/api/stores/${id}`).then((res) => {
      setStore(res.data.store);
    });
  }, []);

  const updateStore = (updatedStore) => {
    axios
      .put(`http://localhost:8080/api/stores/${id}`, updatedStore)
      .then((res) => {
        nav(`/store/${id}`);
      })
      .catch((err) => {
        console.log(err);
        const errorRes = err.response.data.error.errors;
        setFormErrors(errorRes);
      });
  };

  return (
    <div>
        {store && <Form submitForm={updateStore} errors={formErrors} storeInfo={store} />}
    </div>
  );
};

export default Update;
