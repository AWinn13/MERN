import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import{Link} from 'react-router-dom';
import axios from 'axios';
import {
  Box,
  List,
  ListItem,
  Divider,
  ListItemText,
} from '@mui/material';




const Detail = () => {
  const [store, setStore] = useState({});
  const { id } = useParams();

  useEffect(() => {
    axios
      .get(`http://localhost:8080/api/stores/${id}`)
      .then((res) => setStore(res.data.store) )
      
      .catch((err) => console.error(err));
      console.log(store)
  }, []);

  return (
    
    <Box sx={{ width: '100%', maxWidth: 500, margin: '0 auto' }}>
      <Link to={`/`}>Home</Link>
      <Divider />
      <List>
        <ListItem>
          <ListItemText>Name: {store.storeName}</ListItemText>
        </ListItem>
        <Divider />
        <ListItem>
          <ListItemText>Number: {store.storeNumber}</ListItemText>
        </ListItem>
        <Divider />
        <ListItem>
          <ListItemText>{store.storeOpen ? 'Open' : 'closed'}</ListItemText>
        </ListItem>
        <Link to={`/store/edit/${store._id}`}>Edit</Link>
      </List>
    </Box>
  );
};

export default Detail;
