import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Form from '../components/Form';
import { Link} from "react-router-dom";

const Add = () => {
  const nav = useNavigate();
  const [formErrors, setFormErrors] = useState([]);

  const createStore = (newStore) => {
    axios
      .post('http://localhost:8080/api/stores', newStore)
      .then(res => {
        nav('/');
        console.log(res);
      })
      .catch((err) => {
        console.log(err);
        const errorRes = err.response.data.error.errors;
        setFormErrors(errorRes);
      });
  };

  return (
    <div><Link to='/'>Home</Link>
        <h3>Add an Store</h3>
        
      <Form
        submitForm={createStore}
        errors={formErrors}
        storeInfo={{  }}
      />
    </div>
  );
};

export default Add;