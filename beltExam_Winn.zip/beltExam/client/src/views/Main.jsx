import axios from 'axios';
import React, { useState, useEffect } from 'react';
import DeleteButton from '../components/DeleteButton';
import Box from '@mui/material/Box';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Link} from "react-router-dom";
import { Button } from '@mui/material';


const Main = () => {
  const [storeList, setStoreList] = useState([]);

  useEffect(() => {
    axios
      .get('http://localhost:8080/api/stores')
      .then((res) => {
        setStoreList(res.data.stores);
      })
      .catch((err) => console.log(err));
  }, []);

  const removeFromDom = (storeDelete) =>{
    setStoreList(storeList.filter((store)=>store._id !== storeDelete))
};
  

  return (
    <div>
      <Link to={'/'}>HOME</Link>
      <Paper elevation={2}>
        <Box sx={{ width: 350, margin: '0 auto' }}>
          <TableContainer>
            <Table sx={{ width: '100%', maxWidth: 400, margin: '0 auto' }}>
              <TableHead>
                <TableRow>
                  <TableCell>Store</TableCell>
                  <TableCell>Store Number</TableCell>
                  <TableCell>Open</TableCell>
                  <TableCell>Remove</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {storeList &&
                  storeList.map((store, i) => (
                    <TableRow>
                      <TableCell><Button><Link key={i} to={`/store/${store._id}`}> {store.storeName}</Link></Button></TableCell>
                      <TableCell>{store.storeNumber}</TableCell>
                      <TableCell>{store.storeOpen ? 'Open' : 'closed'}</TableCell>
                      <TableCell>{store.storeOpen ? <DeleteButton storeId={store._id} successCallback={() =>removeFromDom(store._id)} /> : ''}
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      </Paper>
      <Link to='/store/add'><Button>Cant Find Your Store?</Button> </Link>
    </div>
  );
};

export default Main;